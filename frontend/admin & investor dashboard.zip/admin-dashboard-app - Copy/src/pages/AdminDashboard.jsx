import React from "react";
import { Card, CardContent } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { User, Megaphone, Ban, FileCheck2 } from "lucide-react";
import { useNavigate } from "react-router-dom";
import adminBg from "../assets/background.png";

const AdminDashboard = () => {
  const navigate = useNavigate();

  const adminActions = [
    {
      label: "View Feedback",
      icon: <User className="h-6 w-6" />, 
      action: () => navigate("/admin/feedback")
    },
    {
      label: "Property Listing Approval",
      icon: <FileCheck2 className="h-6 w-6" />, 
      action: () => navigate("/admin/listing-approval")
    },
    {
      label: "Suspend Accounts",
      icon: <Ban className="h-6 w-6" />, 
      action: () => navigate("/admin/suspend-users")
    },
    {
      label: "Announcements",
      icon: <Megaphone className="h-6 w-6" />, 
      action: () => navigate("/admin/announcements")
    },
  ];

  return (
    <div
      className="min-h-screen p-6 bg-cover bg-no-repeat bg-center"
      style={{ backgroundImage: `url(${adminBg})` }}
    >
      <div className="max-w-4xl mx-auto text-center">
        <div className="bg-white rounded-2xl p-6 shadow-md">
          <h1 className="text-3xl font-bold mb-4">Admin Settings</h1>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-6">
            {adminActions.map((item, index) => (
              <Card
                key={index}
                onClick={item.action}
                className="cursor-pointer hover:shadow-xl transition-all"
              >
                <CardContent className="flex items-center gap-4 p-4">
                  <div className="bg-indigo-100 p-3 rounded-full">
                    {item.icon}
                  </div>
                  <span className="text-lg font-medium">{item.label}</span>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
