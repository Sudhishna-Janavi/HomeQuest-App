import React, { useState } from "react";
import { Card, CardContent } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import investorBg from "../assets/background.png";

const mockTrackedProperties = [
  { id: 1, name: "Condo @ Clementi", yield: "3.8%", trend: [
    { month: "Jan", price: 820 },
    { month: "Feb", price: 830 },
    { month: "Mar", price: 845 },
  ] },
  { id: 2, name: "HDB @ Sengkang", yield: "4.5%", trend: [
    { month: "Jan", price: 450 },
    { month: "Feb", price: 455 },
    { month: "Mar", price: 460 },
  ] },
];

const InvestorDashboard = () => {
  const [price, setPrice] = useState("");
  const [rent, setRent] = useState("");
  const [years, setYears] = useState(1);
  const [roi, setRoi] = useState(null);
  const [error, setError] = useState("");

  const calculateROI = () => {
    const priceNum = parseFloat(price);
    const rentNum = parseFloat(rent);
    const yearsNum = parseFloat(years);

    if (priceNum > 0 && rentNum > 0 && yearsNum > 0) {
      const result = ((rentNum * 12 * yearsNum) / priceNum) * 100;
      setRoi(result.toFixed(2));
      setError("");
    } else {
      setRoi(null);
      setError("Please enter valid positive numbers for all fields.");
    }
  };

  return (
    <div
      className="min-h-screen p-6 bg-cover bg-no-repeat bg-center"
      style={{ backgroundImage: `url(${investorBg})` }}
    >
      <h1 className="text-3xl font-bold mb-6 text-center">Investor Dashboard</h1>

      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Tracked Properties</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {mockTrackedProperties.map((property) => (
            <Card key={property.id} className="hover:shadow-lg transition-all">
              <CardContent>
                <h3 className="text-lg font-bold mb-1">{property.name}</h3>
                <p className="text-sm mb-2">Estimated Yield: {property.yield}</p>
                <div className="h-40">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={property.trend}>
                      <XAxis dataKey="month" />
                      <YAxis domain={[400, 900]} />
                      <Tooltip />
                      <Line type="monotone" dataKey="price" stroke="#3b82f6" strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
                <Button className="mt-4 w-full">Generate Report</Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-4">ROI Calculator</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white p-6 rounded shadow">
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium">HDB Price</label>
                <input
                  type="number"
                  min="0"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  className="w-full border rounded p-2"
                />
              </div>
              <div>
                <label className="block text-sm font-medium">Monthly Rent</label>
                <input
                  type="number"
                  min="0"
                  value={rent}
                  onChange={(e) => setRent(e.target.value)}
                  className="w-full border rounded p-2"
                />
              </div>
              <div>
                <label className="block text-sm font-medium">Expected Hold Time (Years)</label>
                <input
                  type="number"
                  min="0"
                  value={years}
                  onChange={(e) => setYears(e.target.value)}
                  className="w-full border rounded p-2"
                />
              </div>
              <Button onClick={calculateROI}>Calculate</Button>
              {roi && <p className="mt-2 text-lg">Estimated ROI: <strong>{roi}%</strong></p>}
              {error && <p className="text-red-600 text-sm mt-2">{error}</p>}
            </div>
          </div>
        </div>
      </section>

      <section>
        <h2 className="text-xl font-semibold mb-4">Search History</h2>
        <ul className="list-disc ml-6 text-gray-700">
          <li>Resale 3BR units in Punggol (Mar 2025)</li>
          <li>Rental condos with less than 4% yield (Feb 2025)</li>
        </ul>
      </section>
    </div>
  );
};

export default InvestorDashboard;