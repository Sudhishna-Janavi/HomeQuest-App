import React from "react";
import adminBg from "../../assets/background.png";

const FeedbackPanel = () => {
  const feedbacks = [
    { id: 1, user: "Tenant01", message: "Map feature is buggy.", date: "2025-03-20" },
    { id: 2, user: "Investor007", message: "Add more filters in search.", date: "2025-03-21" },
  ];

  return (
    <div
      className="min-h-screen p-6 bg-cover bg-no-repeat bg-center"
      style={{ backgroundImage: `url(${adminBg})` }}
    >
      <div className="max-w-3xl mx-auto bg-white p-6 rounded shadow">
        <h2 className="text-2xl font-bold mb-4">User Feedback</h2>
        <ul className="space-y-4">
          {feedbacks.map((fb) => (
            <li key={fb.id} className="bg-gray-100 p-4 rounded shadow">
              <p className="text-sm text-gray-500">{fb.date} — {fb.user}</p>
              <p>{fb.message}</p>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default FeedbackPanel;
