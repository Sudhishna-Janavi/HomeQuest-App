import React from "react";
import adminBg from "../../assets/background.png";

const ListingApproval = () => {
  const listings = [
    { id: 1, title: "3BR Condo in Bedok", submittedBy: "agent_x", status: "Pending" },
    { id: 2, title: "HDB in Yishun", submittedBy: "landlord_y", status: "Pending" },
  ];

  return (
    <div
      className="min-h-screen p-6 bg-cover bg-no-repeat bg-center"
      style={{ backgroundImage: `url(${adminBg})` }}
    >
      <div className="max-w-3xl mx-auto bg-white p-6 rounded shadow">
        <h2 className="text-2xl font-bold mb-4">Property Listing Approval</h2>
        {listings.map((listing) => (
          <div key={listing.id} className="bg-gray-100 p-4 rounded shadow mb-4">
            <p><strong>{listing.title}</strong> (by {listing.submittedBy})</p>
            <div className="mt-2 space-x-2">
              <button className="bg-green-500 text-white px-3 py-1 rounded hover:bg-green-600">
                Approve
              </button>
              <button className="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600">
                Reject
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ListingApproval;
