import React, { useState } from "react";
import adminBg from "../../assets/background.png";

const Announcements = () => {
  const [announcements, setAnnouncements] = useState([
    {
      id: 1,
      title: "New Features Coming!",
      message: "ROI Calculator launching next week.",
      date: "2025-03-22",
    },
  ]);

  return (
    <div
      className="min-h-screen p-6 bg-cover bg-no-repeat bg-center"
      style={{ backgroundImage: `url(${adminBg})` }}
    >
      <div className="max-w-3xl mx-auto bg-white p-6 rounded shadow">
        <h2 className="text-2xl font-bold mb-4">Platform Announcements</h2>
        <ul className="space-y-4 mb-6">
          {announcements.map((a) => (
            <li key={a.id} className="bg-gray-100 p-4 rounded shadow">
              <h3 className="text-lg font-semibold">{a.title}</h3>
              <p className="text-sm text-gray-500 mb-1">{a.date}</p>
              <p>{a.message}</p>
            </li>
          ))}
        </ul>
        <button className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
          + New Announcement
        </button>
      </div>
    </div>
  );
};

export default Announcements;
