import React from "react";
import adminBg from "../../assets/background.png";

const SuspendUsers = () => {
  const users = [
    { id: 1, username: "tenant123", status: "Active" },
    { id: 2, username: "landlord456", status: "Suspended" },
  ];

  return (
    <div
      className="min-h-screen p-6 bg-cover bg-no-repeat bg-center"
      style={{ backgroundImage: `url(${adminBg})` }}
    >
      <div className="max-w-4xl mx-auto bg-white p-6 rounded shadow">
        <h2 className="text-2xl font-bold mb-4">Manage User Accounts</h2>
        <table className="w-full text-left border">
          <thead>
            <tr className="bg-gray-200">
              <th className="p-2">Username</th>
              <th className="p-2">Status</th>
              <th className="p-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user) => (
              <tr key={user.id} className="border-t">
                <td className="p-2">{user.username}</td>
                <td className="p-2">{user.status}</td>
                <td className="p-2">
                  <button className="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600">
                    {user.status === "Active" ? "Suspend" : "Unsuspend"}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default SuspendUsers;
