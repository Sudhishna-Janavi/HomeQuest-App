import React from "react";
import { Routes, Route } from "react-router-dom";
import AdminDashboard from "./pages/AdminDashboard";
import FeedbackPanel from "./pages/admin/FeedbackPanel";
import SuspendUsers from "./pages/admin/SuspendUsers";
import ListingApproval from "./pages/admin/ListingApproval";
import Announcements from "./pages/admin/Announcements";
import InvestorDashboard from "./pages/InvestorDashboard";

function App() {
  return (
    <Routes>
      <Route path="/admin/dashboard" element={<AdminDashboard />} />
      <Route path="/admin/feedback" element={<FeedbackPanel />} />
      <Route path="/admin/suspend-users" element={<SuspendUsers />} />
      <Route path="/admin/listing-approval" element={<ListingApproval />} />
      <Route path="/admin/announcements" element={<Announcements />} />
      <Route path="/investor/dashboard" element={<InvestorDashboard />} />
    </Routes>
  );
}

export default App;
